<div class="header">
	<!-- navigation bar -->
	
	<ul>
		<li><a href="">Home</a></li>
		<?php 
		$sql = "Select * From Category";
		$rows = query($sql);
		for($i=0; $i<count($rows); $i++)
		{
		?>
		<li><a href="index.php?catid=<?=$rows[$i][0]?>"><?=$rows[$i][1]?></a></li>
		<?php
		}
		?>
	</ul>
</div>