<!DOCTYPE html>
<html lang = "en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>1633</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <?php
    $categories = query("SELECT * FROM category");
    //if the user clicked on a category, show the products in that category
    if (isset($_GET['category']) && $_GET['category'] != "all") {
        $category = $_GET['category'];
        $productsfull = query("SELECT * FROM product WHERE CatID = $category");
    } else {
        $productsfull = query("SELECT * FROM product");
    }
    if (isset($_GET['search'])) {
        $search = $_GET['search'];
        $productsfull = query("SELECT * FROM product LEFT JOIN category ON product.CatId = category.CatId WHERE product.ProductName LIKE '%$search%'");
    }
    ?>
    </head>
    <body>
        <!--Create a template navbar with Home, login, contact, about us, and sign up with all the elements in the center horizontally and dark background-->
        <nav class="navbar navbar-light navbar-expand-lg navigation-clean" style="background: rgba(255,255,255,0);margin-top: -15px;margin-bottom: -31px;">
        <div class="container">
            <div class="collapse navbar-collapse" id="navcol-2">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"></li>
                    <li class="nav-item"><a class="nav-link" href="signin.php">Login</a></li>
                </ul><a role="button" class="btn btn-primary" href="signup.php" type="button" style="background: rgb(244,186,182);color: rgb(84,84,84);border-style: none;border-radius: 24px;">Sign up</a>
            </div>
        </div>
    </nav>
    <nav class="navbar navbar-light navbar-expand-lg navigation-clean-search" style="background: rgba(255,255,255,0);color: rgb(51, 51, 51);">
        <div class="container"><a class="navbar-brand" href="Eshop.php">Phone store</a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1" style="margin-right: 0;">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="Eshop.php">Home</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"></li>
                    <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">Products</a>
                        <div class="dropdown-menu">
                            <!--Use php to display each category with dropdown item -->
                            <?php foreach($categories as $category): ?>
                            <a class="dropdown-item" href="eshop.php?category=<?php echo $category[0]; ?>"><?php echo $category[1]; ?></a>
                            <?php endforeach; ?>
                    </div>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">About us</a></li>
                    <li class="nav-item"></li>
                </ul>
            </div>
            <form class="d-xl-flex ms-auto" method="get"><i class="fa fa-search fs-5 text-muted" style="margin-top: auto;margin-bottom: auto;margin-right: 7px;"></i><input class="form-control" id="search" name="search" placeholder="Search"type="search" style="border-radius: 16px;"></form>
        </div>
    </nav>
    </body>
</html>