<div class="left">
	<div class="block">
		<div class="title">Quicklink 1</div>
		<div class="content">
			<ul>
				<li><a href="">Link 1</a></li>
				<li><a href="">Link 2</a></li>
				<li><a href="">Link 3</a></li>
				<li><a href="">Link 4</a></li>
				<li><a href="">Link 5</a></li>
			</ul>
		</div>
	</div>
	<div class="block">
		<div class="title">Quicklink 2</div>
		<div class="content">
			<ul>
				<li><a href="">Link 1</a></li>
				<li><a href="">Link 2</a></li>
				<li><a href="">Link 3</a></li>
				<li><a href="">Link 4</a></li>
				<li><a href="">Link 5</a></li>
			</ul>
		</div>
	</div>
	<div class="block">
		<div class="title">Quicklink 3</div>
		<div class="content">
			<ul>
				<li><a href="">Link 1</a></li>
				<li><a href="">Link 2</a></li>
				<li><a href="">Link 3</a></li>
				<li><a href="">Link 4</a></li>
				<li><a href="">Link 5</a></li>
			</ul>
		</div>
	</div>
</div>