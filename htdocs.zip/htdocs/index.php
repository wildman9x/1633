<!DOCTYPE html>
<html>
<head>
	<title>Lab 3</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<?php 
//liên kết file db.php vào file index để có các hàm kết nối csdl
require_once('./db.php');

if(isset($_POST['add']))
{

	$id = $_POST['id'];
	$name = $_POST['name'];
	if($_FILES)
	{
		$image = $_FILES['image']['name'];
		$path = "images/" . $image;
		move_uploaded_file($_FILES['image']['tmp_name'], $path);
	}
	
	$cat = $_POST['cat'];
	$price = $_POST['price'];
	$sql = "Insert Into product values('" . $id . "', '" . $name . "', '" . $path . "', " . $price . ", " . $cat . ")";
	
	execsql($sql);
}
if(isset($_GET['deleteid']))
{
	$id = $_GET['deleteid'];
	$sql = "delete from product where ProductId = '" . $id . "'";
	execsql($sql);
}
if(isset($_POST['update']))
{
	$id = $_POST['id'];
	$name = $_POST['name'];
	$path = $_POST['imageold'];

	if($_FILES)
	{
		if(isset($_FILES['image']['name']) && $_FILES['image']['name'] !='')
		{
			$image = $_FILES['image']['name'];
			$path = "images/" . $image;
			move_uploaded_file($_FILES['image']['tmp_name'], $path);
		}
				
	}
	$cat = $_POST['cat'];
	$price = $_POST['price'];
	$sql = "Update product set ProductName='" . $name . "', Image='" . $path . "', Price=" . $price . ", CatId=" . $cat . " Where ProductId = '" . $id . "'";	
	execsql($sql);
}
?>
<body>
<div class="boundary">
	<?php 
	require_once('header.php');
	?>
	<div class="container">
		<!-- heading and main content -->
		<h1>Web Developers, Inc.</h1>
		<?php 
		require_once('left.php');
		?>
		<?php 
		require_once('right.php');
		?>		
	</div>
	<?php 
	require_once('footer.php') 
	?>
</body>
</html>
