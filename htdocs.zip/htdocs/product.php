<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title id="title">Bootstrap Lab</title>
<!--Import bootstrap-->
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" typle = "text/css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="bootstrapLab.css" rel="stylesheet" type="text/css" />
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<!--Import jQuery before bootstrap.js-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    </head>
    <body>
        <header>
            <?php 
            require_once('db.php');
            //include 'third.php' ;
            $categories = query("SELECT * FROM category");
            //display the product chosen based on its id
            $product = query("SELECT * FROM product WHERE ProductId = '" . $_GET['id'] . "'");
            include 'navbar-template.php';
            ?>
        </header>
        <main>
            <!--Display the information about the product-->
            <!--product[0] is the id, product[1] is the name, product[2] is the image, product[3] is the price, product[4] is the categoryId-->
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo $product[0][2]; ?>" alt="<?php echo $product[0][1]; ?>" class="img-fluid">
                    </div>
                    <div class="col-md-6">
                        <h1><?php echo $product[0][1]; ?></h1>
                        <p>Price: $<?php echo $product[0][3]; ?></p>
                        <p>Category: <?php echo $product[0][4]; ?></p>
                        <p>Description: <?php echo $product[0][5]; ?></p>
                        <p>Quantity: <?php echo $product[0][6]; ?></p>
                        <p>
                            <a onclick="history.go(-1)" class="btn btn-primary">Back</a>
                            <a href="cart.php?id=<?php echo $product[0][0]; ?>" class="btn btn-primary">Add to Cart</a>
                        </p>
                    </div>
                </div>
            </div>
    </body>
</html>