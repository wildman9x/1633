<div class="footer">
	<!-- copyright -->
</div>