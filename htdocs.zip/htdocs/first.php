<html>
    <head>
        <title id="title">First</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </head>
    <!--print hello world in h1 tag 10 times with ul-->
    <body>
        <?php
        //define function sum() that takes two integer and print sum of them
        function sum($a, $b) {
            echo $a + $b;
        }
        //create a table that contain the information of students including name, grade on scale of 10, and city
        $students = array(
            array("name" => "John", "grade" => 10, "city" => "New York"),
            array("name" => "Mary", "grade" => 9, "city" => "Paris"),
            array("name" => "Peter", "grade" => 8, "city" => "London"),
            array("name" => "Sara", "grade" => 7, "city" => "Berlin"),
            array("name" => "Mark", "grade" => 6, "city" => "Rome"),
            array("name" => "Linda", "grade" => 5, "city" => "Tokyo"),
            array("name" => "Paul", "grade" => 4, "city" => "New York"),
            array("name" => "Nancy", "grade" => 3, "city" => "Paris"),
            array("name" => "George", "grade" => 2, "city" => "London"),
            array("name" => "Sarah", "grade" => 1, "city" => "Berlin"),
            array("name" => "Mark", "grade" => 0, "city" => "Rome"),
            array("name" => "Linda", "grade" => -1, "city" => "Tokyo"),
            array("name" => "Paul", "grade" => -2, "city" => "New York"),
            array("name" => "Nancy", "grade" => -3, "city" => "Paris"),
            array("name" => "George", "grade" => -4, "city" => "London"),
            array("name" => "Sarah", "grade" => -5, "city" => "Berlin"),
            array("name" => "Mark", "grade" => -6, "city" => "Rome"),
            array("name" => "Linda", "grade" => -7, "city" => "Tokyo"),
            array("name" => "Paul", "grade" => -8, "city" => "New York"),
            array("name" => "Nancy", "grade" => -9, "city" => "Paris")
        );

        ?>
        <h1>Hello World</h1>
        <ul>
            <?php
                for($i=0; $i<10; $i++){
                    echo "<li>Hello World</li>";
                }
            ?>
        </ul>

        <!--print hello world in h2 tag 10 times with ul, the odd line have color red, the even line have color blue-->
        <h2>Hello World</h2>
        <ul>
            <?php
                for($i=0; $i<10; $i++){
                    if($i%2==0){
                        echo "<li style='color:blue'>Hello World</li>";
                    }else{
                        echo "<li style='color:red'>Hello World</li>";
                    }
                }
            ?>
        </ul>
        
        <!-- create an array of 5 random names, then print them out with ul, each name has a random color-->
        <h3>Random Names</h3>
        <ul>
            <?php
                $names = array("John", "Jane", "Jack", "Jill", "Joe");
                for($i=0; $i<5; $i++){
                    $randomColor = '#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
                    echo "<li style='color:$randomColor'>$names[$i]</li>";
                }
            ?>
        </ul>
        <!--Create a p tag that say "The sum of 10 and 20 is" and display the sum of 10 and 20-->
        <p>The sum of 10 and 20 is <?php sum(10, 20); ?></p>
        <!--Display the students information in a table with a button to toggle show/hide it-->
        <h4>Students Information</h4>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Grade</th>
                    <th>City</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($students as $student){
                        echo "<tr>";
                        echo "<td>$student[name]</td>";
                        echo "<td>$student[grade]</td>";
                        echo "<td>$student[city]</td>";
                        echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
        <button class="btn btn-primary" id="toggle">Toggle</button>
        <script>
            var table = document.querySelector("table");
            var button = document.querySelector("#toggle");
            button.addEventListener("click", function(){
                if(table.style.display == "none"){
                    table.style.display = "table";
                }else{
                    table.style.display = "none";
                }
            });
        </script>
        
        <!-- rick roll the useer with autoplay youtube link-->
        <h4>Rick Roll</h4>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            
    </body>
</html>